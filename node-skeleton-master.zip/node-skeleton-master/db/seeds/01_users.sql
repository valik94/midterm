-- Users table seeds here (Example)
INSERT INTO users (name) VALUES ('Alice');
INSERT INTO users (name) VALUES ('Kira');
